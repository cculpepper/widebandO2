#!/bin/zsh

# WARP
# ====
# oh-my-zsh plugin
#
# @github.com/mfaerevaag/wd

alias wd='. $ZSH/plugins/wd/wd.sh'
